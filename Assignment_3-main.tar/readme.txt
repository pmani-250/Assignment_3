Group Members:

Luis Valle-Arellanes
Crystal Quintanar
Ylicia Godinez
Manasi Patil
Dylan Martin
Nicky Angle


Compile:

g++ thread.cpp -o thread -lpthread 

./thread <insert wanted number>

ex. 

./thread 10
